const inputs = document.querySelectorAll('#myTodo .my-todo-app');
const myTodoFrom = document.querySelector('#myTodo');
const displayTodo = document.querySelector('#display-todo tbody');

let list = JSON.parse(localStorage.getItem('list')) ?? [];
let data = {};
let languages = [];

inputs?.forEach((input) => {
    input.addEventListener('input', function (e) {
        let { name, value, checked } = e.target;

        if(name == 'languages'){
            if(checked){
                languages.push(value);
            }else{
                languages = languages.filter((data)=>{
                    if(data != value){
                        return value;
                    }
                })
            }
            value = languages;                
        }        
        data = { ...data, [name]: value };
    })
})

myTodoFrom?.addEventListener('submit',(event)=>{
    event.preventDefault();

    let newObj = {
        id : Date.now(),
        ...data
    }
    
    list.push(newObj);
    console.log(list);
    
    localStorage.setItem('list',JSON.stringify(list));
});

const handleDisplay = ()=>{
    
    displayTodo.innerHTML = '';

    list.forEach((value,index)=>{
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${value.text}</td>
            <td>${value.date}</td>
            <td>${value.languages}</td>
            <td>
                <button class="btn btn-danger" type="button">Delete</button>
                <button class="btn btn-warning" type="button">Edit</button>
            </td>
        `
        displayTodo.appendChild(row);
    })
}

if(displayTodo){
    handleDisplay();
}